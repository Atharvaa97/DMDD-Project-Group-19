<?php
$CollegeID = $_POST['CollegeID'];
$CollegeName = $_POST['CollegeName'];

$servername = "localhost";
$username = "root";
$password = "";
$database = "mystore";

$connection = new mysqli($servername, $username, $password, $database);
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

$sql = "UPDATE college set CollegeName='$CollegeName' where CollegeID='$CollegeID'";

if ($connection->query($sql) === TRUE) {
	echo "Record updated: ".$CollegeID."-".$CollegeName."-";
    header('Location: Colleges.php');
} else {
	echo "Error: ".$sql."<br>".$connection->error;
}
?>