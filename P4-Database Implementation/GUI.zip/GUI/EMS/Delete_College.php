<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "mystore";
error_reporting(0);

$connection = new mysqli($servername, $username, $password, $database);
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

$CollegeID= $_GET['cID'];
$sql = "DELETE FROM college WHERE CollegeID = '$CollegeID'";

$data=mysqli_query($connection,$sql);

if($data)
{
    echo "Record deleted from the database successfully";
    header('Location: Colleges.php');
}
else
{
    echo "Unable to delete the record";
}
?>