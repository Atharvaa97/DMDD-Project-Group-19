<?php

$ClubID = $_POST['ClubID'];
$ClubName = $_POST['ClubName'];

$servername = "localhost";
$username = "root";
$password = "";
$database = "mystore";

$connection = new mysqli($servername, $username, $password, $database);
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

$sql = "UPDATE studentClub set ClubName='$ClubName' where ClubID='$ClubID'";

if ($connection->query($sql) === TRUE) {
    header('Location: StudentClubs.php');
} else {
	echo "Error: ".$sql."<br>".$connection->error;
}
?>