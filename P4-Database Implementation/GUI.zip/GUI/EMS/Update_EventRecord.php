<?php

$EventID = $_POST['EventID'];
$EventName = $_POST['EventName'];
$EventType = $_POST['EventType'];
$EventDescription = $_POST['EventDescription'];
$EventStartTime = $_POST['EventStartTime'];
$EventEndTime = $_POST['EventEndTime'];
$VenueID = $_POST['VenueID'];

$servername = "localhost";
$username = "root";
$password = "";
$database = "mystore";

$connection = new mysqli($servername, $username, $password, $database);
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

$sql = "UPDATE events set EventName='$EventName', EventType='$EventType', EventDescription='$EventDescription', EventStartDateTime='$EventStartTime', EventEndDateTime='$EventEndTime'  where EventID='$EventID'";

if ($connection->query($sql) === TRUE) {
    header('Location: Events.php');
} else {
	echo "Error: ".$sql."<br>".$connection->error;
}
?>