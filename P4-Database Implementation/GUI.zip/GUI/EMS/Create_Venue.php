<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "mystore";

$connection = new mysqli($servername, $username, $password, $database);
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

$VenueID = mysqli_real_escape_string($connection, $_REQUEST['venue_id']);
$VenueName = mysqli_real_escape_string($connection, $_REQUEST['venue_name']);
$VenueAddress = mysqli_real_escape_string($connection, $_REQUEST['venue_address']);
$Capacity = mysqli_real_escape_string($connection, $_REQUEST['capacity']);

// Attempt insert query execution
$sql = "INSERT INTO venue (VenueID, VenueName, VenueAddress, Capacity) VALUES ('$VenueID', '$VenueName', '$VenueAddress','$Capacity')";
if(mysqli_query($connection, $sql)){
    echo "Records added successfully.";
    header('Location: Venues.php');
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($connection);
}
 
// Close connection
mysqli_close($connection);
?>