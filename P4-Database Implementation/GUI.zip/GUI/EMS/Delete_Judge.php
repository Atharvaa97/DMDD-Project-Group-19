<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "mystore";
error_reporting(0);

$connection = new mysqli($servername, $username, $password, $database);
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

$JudgeID= $_GET['jID'];
$sql = "DELETE FROM Judge WHERE JudgeID = '$JudgeID'";

$data=mysqli_query($connection,$sql);

if($data)
{
    echo "Record deleted from the database successfully";
    header('Location: Judge.php');
}
else
{
    echo "Unable to delete the record";
}
?>