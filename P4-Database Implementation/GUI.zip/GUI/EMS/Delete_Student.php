<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "mystore";
error_reporting(0);

$connection = new mysqli($servername, $username, $password, $database);
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

$StudentID= $_GET['sID'];
$sql = "DELETE FROM students WHERE StudentID = '$StudentID'";

$data=mysqli_query($connection,$sql);

if($data)
{
    header('Location: Students.php');
}
else
{
    echo "Unable to delete the record";
}
?>