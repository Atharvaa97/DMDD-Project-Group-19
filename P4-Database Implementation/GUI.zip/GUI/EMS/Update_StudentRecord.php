<?php

$StudentID = $_POST['StudentID'];
$StudentName = $_POST['StudentName'];
$StudentAddress = $_POST['StudentAddress'];
$StudentPhone = $_POST['StudentPhone'];
$StudentEmail = $_POST['StudentEmail'];

$servername = "localhost";
$username = "root";
$password = "";
$database = "mystore";

$connection = new mysqli($servername, $username, $password, $database);
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

$sql = "UPDATE students set StudentName='$StudentName', StudentAddress='$StudentAddress', StudentPhone='$StudentPhone', StudentEmail='$StudentEmail'  where StudentID='$StudentID'";

if ($connection->query($sql) === TRUE) {
    header('Location: Students.php');
} else {
	echo "Error: ".$sql."<br>".$connection->error;
}
?>