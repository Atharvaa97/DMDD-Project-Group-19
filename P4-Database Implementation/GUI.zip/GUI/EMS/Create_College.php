<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "mystore";

$connection = new mysqli($servername, $username, $password, $database);
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

$CollegeID = mysqli_real_escape_string($connection, $_REQUEST['college_ID']);
$CollegeName = mysqli_real_escape_string($connection, $_REQUEST['college_name']);

// Attempt insert query execution
$sql = "INSERT INTO college (CollegeID, CollegeName) VALUES ('$CollegeID', '$CollegeName')";
if(mysqli_query($connection, $sql)){
    echo "Record added successfully.";
    header('Location: Colleges.php');
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($connection);
}
 
// Close connection
mysqli_close($connection);
?>