<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "mystore";

$connection = new mysqli($servername, $username, $password, $database);
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

$SponsorID= $_GET['spID'];

$sql = "SELECT * from sponsors where SponsorID ='$SponsorID'";

$result = $connection->query($sql);

$row = $result->fetch_assoc();

$SponsorID = $row['SponsorID'];
$SponsorName = $row['SponsorName'];

echo

"<html>
<body>

<form action='Update_SponsorRecord.php' method='post'>
Sponsor ID:<br>
<input type='text' name='SponsorID' value='$SponsorID'>
<br>
Sponsor Name:<br>
<input type='text' name='SponsorName' value='$SponsorName'><br>
<br>
<input type ='submit'>

</form>

</body>
</html>"
?>