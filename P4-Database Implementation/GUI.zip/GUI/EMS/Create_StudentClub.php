<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "mystore";

$connection = new mysqli($servername, $username, $password, $database);
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

$ClubID = mysqli_real_escape_string($connection, $_REQUEST['club_ID']);
$ClubName = mysqli_real_escape_string($connection, $_REQUEST['club_Name']);

// Attempt insert query execution
$sql = "INSERT INTO studentClub (ClubID, ClubName) VALUES ('$ClubID', '$ClubName')";
if(mysqli_query($connection, $sql)){
    echo "Record added successfully.";
    header('Location: StudentClubs.php');
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($connection);
}
 
// Close connection
mysqli_close($connection);
?>