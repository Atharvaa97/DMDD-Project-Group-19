<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "mystore";

$connection = new mysqli($servername, $username, $password, $database);
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

$EventID = mysqli_real_escape_string($connection, $_REQUEST['event_id']);
$EventName = mysqli_real_escape_string($connection, $_REQUEST['event_name']);
$EventType = mysqli_real_escape_string($connection, $_REQUEST['event_type']);
$EventDescription = mysqli_real_escape_string($connection, $_REQUEST['event_description']);
$EventStartDateTime = mysqli_real_escape_string($connection, $_REQUEST['event_start_time']);
$EventEndDateTime = mysqli_real_escape_string($connection, $_REQUEST['event_end_time']);

// Attempt insert query execution
$sql = "INSERT INTO events (EventID, EventName, EventType, EventDescription,EventStartDateTime,EventEndDateTime) VALUES ('$EventID', '$EventName', '$EventType','$EventDescription', '$EventStartDateTime', '$EventEndDateTime')";
if(mysqli_query($connection, $sql)){
    echo "Records added successfully.";
    header('Location: Events.php');
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($connection);
}
 
// Close connection
mysqli_close($connection);
?>