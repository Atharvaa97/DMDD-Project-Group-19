<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "mystore";

$connection = new mysqli($servername, $username, $password, $database);
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

$JudgeID = mysqli_real_escape_string($connection, $_REQUEST['judge_id']);
$JudgeName = mysqli_real_escape_string($connection, $_REQUEST['judge_name']);
$JudgeDescription = mysqli_real_escape_string($connection, $_REQUEST['judge_description']);

// Attempt insert query execution
$sql = "INSERT INTO Judge (JudgeID, JudgeName, JudgeDescription) VALUES ('$JudgeID', '$JudgeName', '$JudgeDescription')";
if(mysqli_query($connection, $sql)){
    echo "Records added successfully.";
    header('Location: Judge.php');
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($connection);
}
 
// Close connection
mysqli_close($connection);
?>