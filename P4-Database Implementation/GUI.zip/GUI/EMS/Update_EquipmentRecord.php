<?php
$EquipmentID = $_POST['EquipmentID'];
$EquipmentName = $_POST['EquipmentName'];
$Availability = $_POST['Availability'];
$EventID = $_POST['EventID'];

$servername = "localhost";
$username = "root";
$password = "";
$database = "mystore";

$connection = new mysqli($servername, $username, $password, $database);
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

$sql = "UPDATE equipment set EquipmentName='$EquipmentName', Availability = '$Availability' where EquipmentID='$EquipmentID'";

if ($connection->query($sql) === TRUE) {
    header('Location: Equipments.php');
} else {
	echo "Error: ".$sql."<br>".$connection->error;
}
?>