<?php

$SponsorID = $_POST['SponsorID'];
$SponsorName = $_POST['SponsorName'];

$servername = "localhost";
$username = "root";
$password = "";
$database = "mystore";

$connection = new mysqli($servername, $username, $password, $database);
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

$sql = "UPDATE sponsors set SponsorName='$SponsorName' where SponsorID='$SponsorID'";

if ($connection->query($sql) === TRUE) {
    header('Location: Sponsors.php');
} else {
	echo "Error: ".$sql."<br>".$connection->error;
}
?>