<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "mystore";
error_reporting(0);

$connection = new mysqli($servername, $username, $password, $database);
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

$EquipmentID= $_GET['eID'];
$sql = "DELETE FROM equipment WHERE EquipmentID = '$EquipmentID'";

$data=mysqli_query($connection,$sql);

if($data)
{
    echo "Record deleted from the database successfully";
    header('Location: Equipments.php');
}
else
{
    echo "Unable to delete the record";
}
?>