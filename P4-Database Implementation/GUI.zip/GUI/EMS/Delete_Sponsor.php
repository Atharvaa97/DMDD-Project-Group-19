<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "mystore";
error_reporting(0);

$connection = new mysqli($servername, $username, $password, $database);
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

$SponsorID= $_GET['spID'];
$sql = "DELETE FROM sponsors WHERE SponsorID = '$SponsorID'";

$data=mysqli_query($connection,$sql);

if($data)
{
    echo "Record deleted from the database successfully";
    header('Location: Sponsors.php');
}
else
{
    echo "Unable to delete the record";
}
?>