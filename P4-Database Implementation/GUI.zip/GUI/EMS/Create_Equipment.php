<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "mystore";

$connection = new mysqli($servername, $username, $password, $database);
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

$EquipmentID = mysqli_real_escape_string($connection, $_REQUEST['equipment_ID']);
$EquipmentName = mysqli_real_escape_string($connection, $_REQUEST['equipment_Name']);
$Availability = mysqli_real_escape_string($connection, $_REQUEST['availability']);

// Attempt insert query execution
$sql = "INSERT INTO equipment (EquipmentID, EquipmentName, Availability ) VALUES ('$EquipmentID', '$EquipmentName', '$Availability')";
if(mysqli_query($connection, $sql)){
    echo "Record added successfully.";
    header('Location: Equipments.php');
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($connection);
}
 
// Close connection
mysqli_close($connection);
?>