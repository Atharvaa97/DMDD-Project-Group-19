<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Colleges</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/table-style.css">
    <link rel="stylesheet" href="css/table.css">

</head>
<body style="margin: 40px;">
<a class='button_display_main' href='./Homepage.php'>Home</a>
<br>
<br>

    <h1 class="panel_display">List of Colleges in Northeastern University</h1> 
    <br>
    <a class='button_display' href='./Create_College.html'>Add new</a>
    <br>
    <br>
    <table class="table_College">
        <thead>
			<tr>
				<th>College ID</th>
				<th>College Name</th>
			</tr>
		</thead>

        <tbody>
            <?php
            $servername = "localhost";
			$username = "root";
			$password = "";
			$database = "mystore";

			// Create connection
			$connection = new mysqli($servername, $username, $password, $database);

            // Check connection
			if ($connection->connect_error) {
				die("Connection failed: " . $connection->connect_error);
			}

            // read all row from database table
			$sql = "SELECT * FROM college";
			$result = $connection->query($sql);

            if (!$result) {
				die("Invalid query: " . $connection->error);
			}

            // read data of each row
			while($row = $result->fetch_assoc()) {
                echo "<tr>
                    <td>" . $row["CollegeID"] . "</td>
                    <td>" . $row["CollegeName"] . "</td>
                    <td>
                        <a class='button_display' href='Update_College.php?cID=$row[CollegeID]'>Update</a>

                        <a class='button_display' href='Delete_College.php?cID=$row[CollegeID]'>Delete</a>
                    </td>
                </tr>";
            }

            $connection->close();
            ?>
        </tbody>
    </table>
</body>
</html>