<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "mystore";

$connection = new mysqli($servername, $username, $password, $database);
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

$VenueID= $_GET['vID'];

$sql = "SELECT * from venue where VenueID ='$VenueID'";

$result = $connection->query($sql);

$row = $result->fetch_assoc();

$VenueID = $row['VenueID'];
$VenueName = $row['VenueName'];
$VenueAddress = $row['VenueAddress'];
$Capacity = $row['Capacity'];


echo

"<html>
<body>

<form action='Update_VenueRecord.php' method='post'>
Venue ID:<br>
<input type='text' name='VenueID' value='$VenueID'>
<br>
Venue Name:<br>
<input type='text' name='VenueName' value='$VenueName'><br>
<br>
Venue Address:<br>
<input type='text' name='VenueAddress' value='$VenueAddress'><br>
<br>
Capacity:<br>
<input type='text' name='Capacity' value='$Capacity'><br>
<br>
<input type ='submit'>

</form>

</body>
</html>"
?>