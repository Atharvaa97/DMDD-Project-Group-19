<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "mystore";

$connection = new mysqli($servername, $username, $password, $database);
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

$EquipmentID= $_GET['eID'];

$sql = "SELECT * from equipment where EquipmentID ='$EquipmentID'";

$result = $connection->query($sql);

$row = $result->fetch_assoc();

$EquipmentID = $row['EquipmentID'];
$EquipmentName = $row['EquipmentName'];
$Availability = $row['Availability'];
$EventID = $row['EventID'];

echo

"<html>
<body>

<form action='Update_EquipmentRecord.php' method='post'>
Equipment ID:<br>
<input type='text' name='EquipmentID' value='$EquipmentID'>
<br>
Equipment Name:<br>
<input type='text' name='EquipmentName' value='$EquipmentName'><br>
<br>
Availability:<br>
<input type='text' name='Availability' value='$Availability'><br>
<br>
Event ID:<br>
<input type='hidden' name='EventID' value='$EventID'><br>
<br>
<input type ='submit'>

</form>

</body>
</html>"
?>