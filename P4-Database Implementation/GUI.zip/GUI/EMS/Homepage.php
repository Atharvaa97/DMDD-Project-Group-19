<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Homepage</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/table-style.css">
    <style>
p {
  background-image: url('img\Northeastern_Events.jpg');
}
</style> 
</head>
<body style="margin: 40px;">
<a class='button_display_main' href='./Colleges.php'>Colleges</a>
<a class='button_display_main' href='./Events.php'>Events</a>
<a class='button_display_main' href='./Venues.php'>Venue</a>
<a class='button_display_main' href='./Students.php'>Students</a>
<a class='button_display_main' href='./Judge.php'>Judges</a>
<a class='button_display_main' href='./Equipments.php'>Equipments</a>
<a class='button_display_main' href='./StudentClubs.php'>Student Club</a>
<a class='button_display_main' href='./Sponsors.php'>Sponsors</a>
<a class='button_display_main' href='logout.php'>Logout</a>
<br>
<br>
<img src="img\Northeastern_Events.jpg"> 
</body>
</html>