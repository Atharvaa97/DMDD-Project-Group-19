<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "mystore";

$connection = new mysqli($servername, $username, $password, $database);
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

$SponsorID = mysqli_real_escape_string($connection, $_REQUEST['sponsor_ID']);
$SponsorName = mysqli_real_escape_string($connection, $_REQUEST['sponsor_Name']);

// Attempt insert query execution
$sql = "INSERT INTO sponsors (SponsorID, SponsorName) VALUES ('$SponsorID', '$SponsorName')";
if(mysqli_query($connection, $sql)){
    echo "Record added successfully.";
    header('Location: Sponsors.php');
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($connection);
}
 
// Close connection
mysqli_close($connection);
?>