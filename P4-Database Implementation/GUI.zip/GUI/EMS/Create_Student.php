<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "mystore";

$connection = new mysqli($servername, $username, $password, $database);
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

$StudentID = mysqli_real_escape_string($connection, $_REQUEST['student_id']);
$StudentName = mysqli_real_escape_string($connection, $_REQUEST['student_name']);
$StudentAddress = mysqli_real_escape_string($connection, $_REQUEST['student_address']);
$StudentPhone = mysqli_real_escape_string($connection, $_REQUEST['student_phone']);
$StudentEmail = mysqli_real_escape_string($connection, $_REQUEST['student_email']);

// Attempt insert query execution
$sql = "INSERT INTO students (StudentID, StudentName, StudentAddress, StudentPhone, StudentEmail) VALUES ('$StudentID', '$StudentName', '$StudentAddress','$StudentPhone', '$StudentEmail')";
if(mysqli_query($connection, $sql)){
    header('Location: Students.php');
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($connection);
}
 
// Close connection
mysqli_close($connection);
?>