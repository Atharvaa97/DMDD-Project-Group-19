<?php 
$servername = "localhost";
$username = "root";
$password = "";
$database = "mystore";

error_reporting(0);

$connection = new mysqli($servername, $username, $password, $database);
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}
   if($_SERVER["REQUEST_METHOD"] == "POST") {

      $Username = mysqli_real_escape_string($connection,$_POST['Username']);
      $Password = mysqli_real_escape_string($connection,$_POST['Password']); 
      
      $sql = "SELECT * FROM loginform WHERE Username = '$Username' and Password = '$Password'";
      $result = mysqli_query($connection,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      $active = $row['active'];
      
      $count = mysqli_num_rows($result);
      	
      if($count == 1) {
        echo "Successfully logged in.";
        header('Location: homepage.php');
    } else{
        echo "Your Username or Password is invalid ";
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/media.css">
</head>
<body>

    <main class="main">
        <div class="container">
            <div class="forms">
                <div class="sign__blog">

                    <form method="post" action="" class="signin">

                        <div class="profile__img__blog">
                            <img src="img\SystemAdmin.jpg" alt="" class="profile">
                        </div>
                        <br>
                        <div class="input_item">
                            <input name="Username" type="text" class="form_input" oninvalid="this.classList.add('invalid')" required>
                            <label for="Username" class="form_label"><i class="fas fa-user"></i> Username</label>
                        </div>
                        <div class="input_item">
                            <span class="passwordEye"><i class="fas fa-eye-slash"></i></span>
                            <input name="Password" type="password" class="form_input form_pass" oninvalid="this.classList.add('invalid')" required>
                            <label for="Password" class="form_label"><i class="fas fa-lock"></i> Password</label>
                        </div>
                        <button type="submit" class="btn"style="color: white">LOGIN</button>
                    </form>
                </div>
            </div>

            <div class="panels__blog">

                <div class="panel left__panel">

                    <div class="content">

                        <h3 class="panel__title">Event Management System</h3>
                    </div>
                    <img src="img\Northeastern_University_Logo-White.png" alt="" class="panel__img">
                </div>

            </div>

        </div>
    </main>
</body>
</html>


