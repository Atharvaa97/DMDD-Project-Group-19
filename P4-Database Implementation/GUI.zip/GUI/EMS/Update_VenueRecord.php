<?php
$VenueID = $_POST['VenueID'];
$VenueName = $_POST['VenueName'];
$VenueAddress = $_POST['VenueAddress'];
$Capacity = $_POST['Capacity'];

$servername = "localhost";
$username = "root";
$password = "";
$database = "mystore";

$connection = new mysqli($servername, $username, $password, $database);
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

$sql = "UPDATE venue set VenueName='$VenueName', VenueAddress='$VenueAddress', Capacity='$Capacity' where VenueID='$VenueID'";

if ($connection->query($sql) === TRUE) {
    header('Location: Venues.php');
} else {
	echo "Error: ".$sql."<br>".$connection->error;
}
?>