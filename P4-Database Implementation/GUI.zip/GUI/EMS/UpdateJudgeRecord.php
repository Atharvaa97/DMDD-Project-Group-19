<?php

$JudgeID = $_POST['JudgeID'];
$JudgeName = $_POST['JudgeName'];
$JudgeDescription = $_POST['JudgeDescription'];

$servername = "localhost";
$username = "root";
$password = "";
$database = "mystore";

$connection = new mysqli($servername, $username, $password, $database);
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

$sql = "UPDATE Judge set JudgeName='$JudgeName', JudgeDescription='$JudgeDescription' where JudgeID='$JudgeID'";

if ($connection->query($sql) === TRUE) {
	echo "Record updated: ".$JudgeID."-".$JudgeName."-".$JudgeDescription;
    header('Location: Judge.php');
} else {
	echo "Error: ".$sql."<br>".$connection->error;
}

?>