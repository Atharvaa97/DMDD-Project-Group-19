<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "mystore";

$connection = new mysqli($servername, $username, $password, $database);
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

$JudgeID= $_GET['jID'];

$sql = "SELECT * from Judge where JudgeID ='$JudgeID'";

$result = $connection->query($sql);

$row = $result->fetch_assoc();

$JudgeID = $row['JudgeID'];
$JudgeName = $row['JudgeName'];
$JudgeDescription = $row['JudgeDescription'];

echo

"<html>
<body>

<form action='UpdateJudgeRecord.php' method='post'>
JudgeID:<br>
<input type='text' name='JudgeID' value='$JudgeID'>
<br>
JudgeName:<br>
<input type='text' name='JudgeName' value='$JudgeName'><br>
JudgeDescription: <br> 
<input type='text' name='JudgeDescription' value='$JudgeDescription'><br>
<br>
<input type ='submit'>

</form>

</body>
</html>"
?>