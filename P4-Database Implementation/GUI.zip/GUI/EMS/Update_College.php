<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "mystore";

$connection = new mysqli($servername, $username, $password, $database);
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

$CollegeID= $_GET['cID'];

$sql = "SELECT * from college where CollegeID ='$CollegeID'";

$result = $connection->query($sql);

$row = $result->fetch_assoc();

$CollegeID = $row['CollegeID'];
$CollegeName = $row['CollegeName'];

echo

"<html>
<body>

<form action='Update_CollegeRecord.php' method='post'>
College ID:<br>
<input type='text' name='CollegeID' value='$CollegeID'>
<br>
College Name:<br>
<input type='text' name='CollegeName' value='$CollegeName'><br>
<br>
<input type ='submit'>

</form>

</body>
</html>"
?>