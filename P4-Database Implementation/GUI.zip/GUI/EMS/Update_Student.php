<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "mystore";

$connection = new mysqli($servername, $username, $password, $database);
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

$StudentID= $_GET['sID'];

$sql = "SELECT * from students where StudentID ='$StudentID'";

$result = $connection->query($sql);

$row = $result->fetch_assoc();

$StudentID = $row['StudentID'];
$StudentName = $row['StudentName'];
$StudentAddress = $row['StudentAddress'];
$StudentPhone = $row['StudentPhone'];
$StudentEmail = $row['StudentEmail'];


echo

"<html>
<body>

<form action='Update_StudentRecord.php' method='post'>
Student ID:<br>
<input type='text' name='StudentID' value='$StudentID'>
<br>
Student Name:<br>
<input type='text' name='StudentName' value='$StudentName'><br>
<br>
Student Address:<br>
<input type='text' name='StudentAddress' value='$StudentAddress'><br>
<br>
Student Phone:<br>
<input type='text' name='StudentPhone' value='$StudentPhone'><br>
<br>
Student Email:<br>
<input type='text' name='StudentEmail' value='$StudentEmail'><br>
<br>


<input type ='submit'>

</form>

</body>
</html>"
?>