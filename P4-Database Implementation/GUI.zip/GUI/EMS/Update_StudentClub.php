<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "mystore";

$connection = new mysqli($servername, $username, $password, $database);
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

$ClubID= $_GET['clID'];

$sql = "SELECT * from studentclub where ClubID ='$ClubID'";

$result = $connection->query($sql);

$row = $result->fetch_assoc();

$ClubID = $row['ClubID'];
$ClubName = $row['ClubName'];

echo

"<html>
<body>

<form action='Update_StudentClubRecord.php' method='post'>
Club ID:<br>
<input type='text' name='StudentID' value='$ClubID'>
<br>
Club Name:<br>
<input type='text' name='StudentName' value='$ClubName'><br>
<br>

<input type ='submit'>

</form>

</body>
</html>"
?>