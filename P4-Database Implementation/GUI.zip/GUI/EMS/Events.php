<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Venues</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/table-style.css">

</head>
<body style="margin: 40px;">
<a class='button_display_main' href='./Homepage.php'>Home</a>
<br>
<br>

    <h1 class="panel_display">List of Events held in the University</h1> 
    <br>
    <a class='button_display' href='./Create_Event.html'>Add new</a>
    <br>
    <br>
    <table class="table_Event">
        <thead>
			<tr>
				<th>Event ID</th>
				<th>Event Name</th>
                <th>Event Type</th>
				<th>Event Description</th>
                <th>Event StartDateTime</th>
                <th>Event EndDateTime</th>
                <th>Venue ID</th>
			</tr>
		</thead>

        <tbody>
            <?php
            $servername = "localhost";
			$username = "root";
			$password = "";
			$database = "mystore";

			// Create connection
			$connection = new mysqli($servername, $username, $password, $database);

            // Check connection
			if ($connection->connect_error) {
				die("Connection failed: " . $connection->connect_error);
			}

            // read all row from database table
			$sql = "SELECT * FROM events";
			$result = $connection->query($sql);

            if (!$result) {
				die("Invalid query: " . $connection->error);
			}

            // read data of each row
			while($row = $result->fetch_assoc()) {
                echo "<tr>
                    <td>" . $row["EventID"] . "</td>
                    <td>" . $row["EventName"] . "</td>
                    <td>" . $row["EventType"] . "</td>
                    <td>" . $row["EventDescription"] . "</td>
                    <td>" . $row["EventStartDateTime"] . "</td>
                    <td>" . $row["EventEndDateTime"] . "</td>
                    <td>" . $row["VenueID"] . "</td>
                    <td>
                        <a class='button_display' href='Update_Event.php?eID=$row[EventID]'>Update</a>

                        <a class='button_display' href='Delete_Event.php?eID=$row[EventID]'>Delete</a>
                    </td>
                </tr>";
            }

            $connection->close();
            ?>
        </tbody>
    </table>
</body>
</html>