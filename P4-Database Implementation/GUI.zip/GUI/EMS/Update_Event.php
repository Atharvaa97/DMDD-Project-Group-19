<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "mystore";

$connection = new mysqli($servername, $username, $password, $database);
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

$EventID= $_GET['eID'];

$sql = "SELECT * from events where EventID ='$EventID'";

$result = $connection->query($sql);

$row = $result->fetch_assoc();

$EventID = $row['EventID'];
$EventName = $row['EventName'];
$EventType = $row['EventType'];
$EventDescription = $row['EventDescription'];
$EventStartTime = $row['EventStartDateTime'];
$EventEndTime = $row['EventEndDateTime'];
$VenueID = $row['VenueID'];


echo

"<html>
<body>

<form action='Update_EventRecord.php' method='post'>
Event ID:<br>
<input type='text' name='EventID' value='$EventID'>
<br>
Event Name:<br>
<input type='text' name='EventName' value='$EventName'><br>
<br>
Event Type:<br>
<input type='text' name='EventType' value='$EventType'><br>
<br>
Event Description:<br>
<input type='text' name='EventDescription' value='$EventDescription'><br>
<br>
Event StartTime:<br>
<input type='text' name='EventStartTime' value='$EventStartTime'><br>
<br>
Event EndTime:<br>
<input type='text' name='EventEndTime' value='$EventEndTime'><br>
<br>
Venue ID:<br>
<input type='hidden' name='VenueID' value='$VenueID'><br>
<br>

<input type ='submit'>

</form>

</body>
</html>"
?>